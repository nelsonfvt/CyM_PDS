#include "stm32f7xx.h"

int voltaje = 0;
int conversion = 0;	

int16_t aceleracionx, aceleraciony, aceleracionz;
float aceleracionxfinal,aceleracionyfinal, aceleracionzfinal; 
int16_t	Gx,Gy,Gz;
float gx,gy,gz;
int alt;
char env_voltaje[49]; 
#define fast_mode 0x10320309

void send()
{
	for(int i=0;i<49;i++){//For para realizar el envio del vector que almacena los datos
		UART7->TDR=env_voltaje[i];//Env�a los datos almacenados
		while ((UART7->ISR &= 0x80)==0);//Bandera para decir que termino el envio
	}
}

void descomponer(float voltaje,float voltaje2,float voltaje3,float voltaje4,float voltaje5,float voltaje6){//Funci�n para descomponer el voltaje en unidades, decimas y centecimas
	int nn,auxiliar;//Variables auxiliares
	if(voltaje<0){
		env_voltaje[0]='-';
	voltaje=voltaje*-1;
	}
	else{
		env_voltaje[0]='0';}
	
	if(voltaje2<0){
		env_voltaje[8]='-';
	voltaje2=voltaje2*-1;}
	else{
		env_voltaje[8]='0';}
	
	if(voltaje3<0){
		env_voltaje[16]='-';
	voltaje3=voltaje3*-1;}
	else{
		env_voltaje[16]='0';}
	
		
	/////////////////
		
		
	if(voltaje4<0){
		env_voltaje[24]='-';
	voltaje4=voltaje4*-1;}
	else{
		env_voltaje[24]='0';}
	
	if(voltaje5<0){
		env_voltaje[32]='-';
	voltaje5=voltaje5*-1;}
	else{
		env_voltaje[32]='0';}
	
	if(voltaje6<0){
		env_voltaje[40]='-';
	voltaje6=voltaje6*-1;}
	else{
		env_voltaje[40]='0';}
	
	//Descomposici�n
	env_voltaje[7]=';';
	nn=voltaje*100;
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[6]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[5]=auxiliar+'0';
	env_voltaje[4]='.';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[3]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[2]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[1]=auxiliar+'0';
	
	env_voltaje[7+8]=';';
	nn=voltaje2*100;
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[6+8]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[5+8]=auxiliar+'0';
	env_voltaje[4+8]='.';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[3+8]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[2+8]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[1+8]=auxiliar+'0';
	
	
	env_voltaje[7+16]=';';
	nn=voltaje3*100;
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[6+16]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[5+16]=auxiliar+'0';
	env_voltaje[4+16]='.';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[3+16]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[2+16]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[1+16]=auxiliar+'0';
	//env_voltaje[24]='\n';
	
	///////
	
	env_voltaje[7+24]=';';
	nn=voltaje4*100;
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[6+24]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[5+24]=auxiliar+'0';
	env_voltaje[4+24]='.';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[3+24]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[2+24]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[1+24]=auxiliar+'0';
	//env_voltaje[24]='\n';
	
	
	env_voltaje[7+32]=';';
	nn=voltaje5*100;
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[6+32]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[5+32]=auxiliar+'0';
	env_voltaje[4+32]='.';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[3+32]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[2+32]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[1+32]=auxiliar+'0';
	
	env_voltaje[7+40]=';';
	nn=voltaje6*100;
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[6+40]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[5+40]=auxiliar+'0';
	env_voltaje[4+40]='.';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[3+40]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[2+40]=auxiliar+'0';
	auxiliar=nn%10;
	nn=nn/10;
	env_voltaje[1+40]=auxiliar+'0';
	env_voltaje[48]='\n';
	send();
}

void escribir(char direccionEsclavo, char direccionEscribir, char dato){
	I2C2->CR2 |=I2C_CR2_AUTOEND;
	I2C2->CR2 &=~I2C_CR2_RD_WRN; 
	I2C2->CR2 |=(direccionEsclavo<<1); 
	I2C2->CR2 |=(2<<16); 
	I2C2->CR2 |=I2C_CR2_START; 
	while(!(I2C2->ISR & I2C_ISR_TXIS));
	I2C2->TXDR =direccionEscribir;
	while(!(I2C2->ISR & I2C_ISR_TXIS));
	I2C2->TXDR =dato; 
	while(!(I2C2->ISR & I2C_ISR_TXE)); 
	while(!(I2C2->ISR & I2C_ISR_STOPF));
	I2C2->CR2 =0x02000000;  
} 

char leer(char direccionEsclavo,char direccionLeer){ 

	I2C2->CR2 &=~I2C_CR2_RD_WRN; 
	I2C2->CR2 |=(direccionEsclavo<<1); 
	I2C2->CR2 |=(1<<16); 
	I2C2->CR2 |=I2C_CR2_AUTOEND; 
	I2C2->CR2 |=I2C_CR2_START;  
	while(!(I2C2->ISR & I2C_ISR_TXIS));
	I2C2->TXDR = direccionLeer; 
	while (!(I2C2->ISR & I2C_ISR_TXE)); 
	while (!(I2C2->ISR & I2C_ISR_STOPF));

	I2C2->CR1 &= ~I2C_CR1_PE;
	while (I2C2->CR1 & I2C_CR1_PE);
	I2C2->CR1 |=I2C_CR1_PE;

	I2C2->CR2 |=(direccionEsclavo<<1);
	I2C2->CR2 |=I2C_CR2_RD_WRN;
	I2C2->CR2 |=(1<<16);
	I2C2->CR2 |=I2C_CR2_START;
	while (!(I2C2->ISR & I2C_ISR_RXNE)); 
	uint8_t informacion = I2C2->RXDR;
	while (!(I2C2->ISR & I2C_ISR_STOPF)); 
	I2C2->CR2 |=I2C_CR2_STOP;
	
	I2C2->CR1 &= ~I2C_CR1_PE;
	while (I2C2->CR1 & I2C_CR1_PE);
	I2C2->CR1 |=I2C_CR1_PE; 
	return informacion;
}

void lectura(void){			
	aceleracionx = ((leer(0x68,0x3B)<<8) | leer(0x68,0x3C)); // se obtiene  las medidas del sensor tanto en parte alta como baja 
	aceleracionxfinal = (((aceleracionx)*(-9.81)/16384)); // Calculo la aceleracion en x
			
	aceleraciony = ((leer(0x68,0x3D)<<8) | leer(0x68,0x3E));// se obtiene  las medidas del sensor tanto en parte alta como baja
	aceleracionyfinal = (((aceleraciony))*(-9.81)/16384); // Calculo la aceleracion en y
			
	aceleracionz = ((leer(0x68,0x3F)<<8) | leer(0x68,0x40));// se obtiene  las medidas del sensor tanto en parte alta como baja
	aceleracionzfinal = (((aceleracionz))*(-9.81)/16384); // Calculo la aceleracion en z
	
	Gx=((leer(0x68,0x43)<<8) | leer(0x68,0x44));
	gx=(Gx*250)/32770.0;
	
	Gy=((leer(0x68,0x45)<<8) | leer(0x68,0x46));
	gy=(Gy*250)/32770.0;
	
	Gz=((leer(0x68,0x47)<<8) | leer(0x68,0x48));
	gz=(Gz*250)/32770.0;
			
	descomponer(aceleracionzfinal,aceleracionxfinal,aceleracionyfinal,gx,gy,gz);
}

extern "C"
{
	void SysTick_Handler()
	{
		lectura();
	}
}

int main(){
	RCC->AHB1ENR=0xff;	
	
	GPIOF -> MODER |= (2UL << 2*6); // TX - RXF6
	GPIOF -> MODER |= (2UL << 2*7); // RX - TXF7
	GPIOF -> AFR[0] |= 0x8000000;
	GPIOF -> AFR[0] |= 0x80000000;
	
	GPIOF->AFR[0] |=0x00000044; // FUNCION ALTERNANTE 0 y 1 F0 -> SDA F1 -> SCL
	GPIOF->MODER |=0x0000000A; //  ALTERNANTE 0 Y 1 
	GPIOF->OTYPER |=0x00000003; // OPEN DRAIN  
	GPIOF->PUPDR |=0x5; // PULL-UP  
	GPIOF->OSPEEDR |=0xC; // HIGH-SPEED 
	
	RCC -> APB1ENR |= 0x40000000;
	UART7 -> CR1 |= 0x2C;
	UART7 -> CR1 |= 0x1;	
	UART7 -> BRR = 0x10;//Velocidad de 1000000 Baudios
	
	RCC->APB1ENR |=0x00400000;
	RCC->DCKCFGR2 |= 0x80000;  
	I2C2->TIMINGR |=fast_mode;
	I2C2->CR1 |=0x01;  
	escribir(0x68,0x6B,0x00); 
	
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock/1000);
	
	while(true){
	}
}