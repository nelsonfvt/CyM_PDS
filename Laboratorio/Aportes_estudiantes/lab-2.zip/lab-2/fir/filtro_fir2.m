fs = 1000;

figure(1)
b1 = fir1(50,120/(fs/2),'high');
freqz(b1);

figure(2)
b2 = fir1(50,150/(fs/2),'high');
freqz(b2);

figure(3)
b3 = fir1(50,200/(fs/2),'high');
freqz(b3);

figure(4)
b4 = fir1(50,250/(fs/2),'high');
freqz(b4);