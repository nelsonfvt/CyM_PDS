fs = 1000;

f1 = [0 100/fs 500/fs 800/fs 1];
m1 = [1 0 1.5 0.5 1];
b1 = fir2(50,f1,m1);
figure(1)
freqz(b1);

f2 = [0 100/fs 500/fs 800/fs 1];
m2 = [1 0 1 0 1];
b2 = fir2(50,f2,m2);
figure(2)
freqz(b2);

