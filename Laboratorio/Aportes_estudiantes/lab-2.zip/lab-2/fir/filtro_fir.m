fs = 1000;

figure(1)
b1 = fir1(40,250/(fs/2))
freqz(b1);

[b,a] = butter(3,120/(fs/2));
% 
% figure(2)
% b2 = fir1(50,150/(fs/2));
% freqz(b2);
% 
% figure(3)
% b3 = fir1(50,200/(fs/2));
% freqz(b3);
% 
% figure(4)
% b4 = fir1(50,250/(fs/2));
% freqz(b4);