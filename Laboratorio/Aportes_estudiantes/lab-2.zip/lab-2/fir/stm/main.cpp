#include "stm32f7xx.h"

int voltaje = 0;
int conversion = 0;	

float b[41] = {-0.0000,-0.0004,0.0011,-0.0020,0.0032,-0.0046,0.0058,-0.0066,0.0062,-0.0042,0.0000,0.0067,-0.0160,0.0276,-0.0409,0.0551,-0.0690,0.0816,-0.0915,0.0978,0.9002,0.0978,
	            -0.0915,0.0816,-0.0690, 0.0551,-0.0409,0.0276,-0.0160,0.0067,0.0000,-0.0042,0.0062,-0.0066,0.0058,-0.0046,0.0032,-0.0020,0.0011,-0.0004,-0.0000};

float b1[41] = {-0.0000,-0.0014,0.0000,0.0024,-0.0000,-0.0046,0.0000,0.0081,-0.0000,-0.0136,0.0000,0.0217,-0.0000,-0.0341,0.0000,0.0551,-0.0000,-0.1009,0.0000,0.3169,0.5006,0.3169,
                0.0000,-0.1009,-0.0000,0.0551,0.0000,-0.0341,-0.0000,0.0217,0.0000,-0.0136,-0.0000,0.0081,0.0000,-0.0046,-0.0000,0.0024,0.0000,-0.0014,-0.0000};
int x[41]={0};	
int y = 0;

void send()
{
	
		UART7 -> TDR = y;//ENVIAR DATOS 
		while((UART7 -> ISR &= 0X80) == 0);	//EVALUAR SI LA BANDERA TXE ESTA ACTIVA	
}

extern "C"
{
	void SysTick_Handler()
	{
		GPIOA -> ODR ^= 1;
		
		ADC1 -> SQR3 = 11; //Canal 11 ADC
		ADC1 -> CR2 |= (1UL << 30); //Inicia la conversion en los canales
	
		while((ADC1 -> SR &= 0x2) == 1); //Espera a que la conversion este completa
	
		voltaje = (ADC1 -> DR);
		x[0] = voltaje;
		y = 0;
		for(int i = 0; i < 41; i++)
		{
			y += x[40-i]*b[40-i];
			x[40-i] = x[39-i];
		}
		
		//send();
		
		conversion = (y*100)/4095;
		
		TIM3 -> CCR1 = conversion;
	}
}

int main(){
	RCC->AHB1ENR=0xff;
	RCC->APB1ENR|=(1UL << 1);//Tim3
	RCC -> APB2ENR |= (1UL << 8); //Activacion ADC1
	
	GPIOA->MODER|=0x2001;
	GPIOA -> AFR[0] = 0x2000000;
	
	GPIOC->MODER|=15;
	
//	GPIOF -> MODER |= (2UL << 2*6); // TX - RXF6
//	GPIOF -> MODER |= (2UL << 2*7); // RX - TXF7
//	GPIOF -> AFR[0] |= 0x8000000;
//	GPIOF -> AFR[0] |= 0x80000000;
//	
//	RCC -> APB1ENR |= 0x40000000;
//	UART7 -> BRR |= 0x8B;
//	UART7 -> CR1 |= 0x2C;
//	UART7 -> CR1 |= 0x1;	
//	NVIC_EnableIRQ(UART7_IRQn);
	
	ADC1 -> CR1 |= 0x0; //Resolucion a 12 bits
	ADC1 -> CR2 |= 0x1; //Bit 0 Enable ADC 
	
	TIM3 -> EGR |= (1UL << 0);
	TIM3 -> PSC |= 15;
	TIM3 -> ARR = 100;
	TIM3 -> DIER |= (1UL << 0);
	
	TIM3 -> CR1 |= (1UL << 0);
	TIM3 -> CCMR1 |= 0x60;
	TIM3 -> CCER |= (1UL << 0);
	
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock/1000);
	
	while(true){
	}
}