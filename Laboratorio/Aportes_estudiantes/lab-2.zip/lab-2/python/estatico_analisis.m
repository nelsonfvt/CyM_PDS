open('estatico.xlsx');
M = readtable('estatico.xlsx');
Ac_x = table2array(M(:,2));
Ac_y = table2array(M(:,3));
Ac_z = table2array(M(:,1));
 
Gy_x = table2array(M(:,4));
Gy_y = table2array(M(:,5));
Gy_z = table2array(M(:,6));

n = 0:1:10000-1;
figure()
subplot(2,3,1)
plot(n,Ac_x,'r.')
title('Acelerometro eje X')
xlabel('Tiempo (muestras)')
subplot(2,3,2)
plot(n,Ac_x,'r.')
title('Acelerometro eje Y')
xlabel('Tiempo (muestras)')
subplot(2,3,3)
plot(n,Ac_z,'r.')
title('Acelerometro eje Z')
xlabel('Tiempo (muestras)')

subplot(2,3,4)
plot(n,Gy_x,'r.')
title('Giroscopo eje X')
xlabel('Tiempo (muestras)')
subplot(2,3,5)
plot(n,Gy_y,'r.')
title('Giroscopo eje Y')
xlabel('Tiempo (muestras)')
subplot(2,3,6)
plot(n,Gy_z,'r.')
title('Giroscopo eje Z')
xlabel('Tiempo (muestras)')


FAc_x = abs(fft(Ac_x));
Fac_x(1)=0;

FAc_y = abs(fft(Ac_y));
Fac_y(1)=0;

FAc_z = abs(fft(Ac_z));
Fac_z(1)=0;

FGy_x = abs(fft(Gy_x));
FGy_x(1) = 0;

FGy_y = abs(fft(Gy_y));
FGy_y(1) = 0;

FGy_z = abs(fft(Gy_z));
FGy_z(1) = 0;

fr = n*1000/length(FAc_x);
figure()
subplot(2,3,1)
plot(fr,FAc_x)
title('Acelerometro eje x')
xlabel('Frecuencia (Hz)')
subplot(2,3,2)
plot(fr,FAc_y)
title('Acelerometro eje y')
xlabel('Frecuencia (Hz)')
subplot(2,3,3)
plot(fr,FAc_z)
title('Acelerometro eje z')
xlabel('Frecuencia (Hz)')

subplot(2,3,4)
plot(fr,FGy_x)
title('Giroscopo eje x')
xlabel('Frecuencia (Hz)')
subplot(2,3,5)
plot(fr,FGy_y)
title('Giroscopo eje y')
xlabel('Frecuencia (Hz)')
subplot(2,3,6)
plot(fr,FGy_z)
title('Giroscopo eje z')
xlabel('Frecuencia (Hz)')