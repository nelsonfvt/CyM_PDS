import serial
import pandas as pd

#(805/1000000)
# Vector escalar de datos
xt = []

# open serial port
ser = serial.Serial('COM6', 1000000)

try:
    for i in range (10000):
        x = ser.readline()
        xt.append(x);
except KeyboardInterrupt:
    pass

ser.close()

datos = pd.DataFrame(xt[:])

datos.to_csv('movimiento.csv', index = False, sep = ';')


