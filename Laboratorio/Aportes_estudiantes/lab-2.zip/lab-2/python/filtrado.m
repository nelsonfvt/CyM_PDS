open('estatico.xlsx');
open('movimiento.xlsx');
M = readtable('movimiento.xlsx');
S = readtable('estatico.xlsx');

Ac_x = table2array(S(:,2));
Ac_y = table2array(S(:,3));
Ac_z = table2array(S(:,1));
 
Gy_x = table2array(S(:,4));
Gy_y = table2array(S(:,5));
Gy_z = table2array(S(:,6));

Ac_x1 = table2array(M(:,2));
Ac_y1 = table2array(M(:,3));
Ac_z1 = table2array(M(:,1));
 
Gy_x1 = table2array(M(:,4));
Gy_y1 = table2array(M(:,5));
Gy_z1 = table2array(M(:,6));

n = 0:1:10000-1;

figure()
subplot(2,2,1)
plot(n,Ac_z,'r.')
title('Acelerometro eje Z estático')
xlabel('Tiempo (muestras)')
subplot(2,2,2)
plot(n,Gy_x,'r.')
title('Giróscopo eje X estático')
xlabel('Tiempo (muestras)')
subplot(2,2,3)
plot(n,Ac_z1,'r.')
title('Acelerometro eje Z movimiento')
xlabel('Tiempo (muestras)')
subplot(2,2,4)
plot(n,Gy_x1,'r.')
title('Giróscopo eje X movimiento')
xlabel('Tiempo (muestras)')

FsAc_z = abs(fft(Ac_z));
FsAc_z(1) = 0;
FsGy_x = abs(Gy_x);
FsGy_x(1) = 0;

FmAc_z = abs(fft(Ac_z1));
FmAc_z(1) = 0;
FmGy_x = abs(fft(Gy_x1));
FmGy_x(1) = 0;

fr = n*1000/length(FsAc_z);
figure()
subplot(2,2,1)
plot(fr,FsAc_z)
title('Acelerometro eje Z estático')
xlabel('Frecuencia (Hz)')
subplot(2,2,2)
plot(fr,FsGy_x)
title('Giróscopo eje x estático')
xlabel('Frecuencia (Hz)')
subplot(2,2,3)
plot(fr,FmAc_z)
title('Acelerometro eje x movimiento')
xlabel('Frecuencia (Hz)')
subplot(2,2,4)
plot(fr,FmGy_x)
title('Giróscopo eje x movimiento')
xlabel('Frecuencia (Hz)')


%Filtro FIR por enventanado
Fs = 1000; %muestras/segundo
Fc = 10; %ciclos/segundo
fc = 2*(Fc/Fs); %Pi rad/muestra
hn = fir1(50,fc);
figure()
freqz(hn,1)

%filtrando señales estáticas
Acf_z = filter(hn,1,Ac_z);
Gyf_x = filter(hn,1,Gy_x);

Acs_z = abs(fft(Acf_z));
Acs_z(1) = 0;
Gys_x = abs(fft(Gyf_x));
Gys_x(1) = 0;

f = figure();
f.Name = 'Sensor sin movimiento';
subplot(2,2,1)
plot(n,Acf_z,'r.')
title('Acelerómetro eje Z filtrado')
xlabel('muestras')
subplot(2,2,2)
plot(n,Gyf_x,'r.')
title('Giróscopo eje X filtrado')
subplot(2,2,3)
plot(fr,Acs_z)
title('Espectro de frecuencia')
xlabel('frecuencia (Hz)')
subplot(2,2,4)
plot(fr,Gys_x)
title('Espectro de frecuencia')
xlabel('frecuencia (Hz)')

%filtrando señales en movimiento
Acf_z1 = filter(hn,1,Ac_z1);
Gyf_x1 = filter(hn,1,Gy_x1);

Acs_z1 = abs(fft(Acf_z1));
Acs_z1(1) = 0;
Gys_x1 = abs(fft(Gyf_x1));
Gys_x1(1) = 0;

f = figure();
f.Name = 'Sensor con movimiento';
subplot(2,2,1)
plot(n,Acf_z1,'r.')
title('Acelerómetro eje Z filtrado')
xlabel('muestras')
subplot(2,2,2)
plot(n,Gyf_x1,'r.')
title('Giróscopo eje X filtrado')
subplot(2,2,3)
plot(fr,Acs_z1)
title('Espectro de frecuencia')
xlabel('frecuencia (Hz)')
subplot(2,2,4)
plot(fr,Gys_x1)
title('Espectro de frecuencia')
xlabel('frecuencia (Hz)')
